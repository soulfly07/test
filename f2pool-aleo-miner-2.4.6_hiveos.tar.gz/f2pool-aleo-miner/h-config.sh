####################################################################################
###
### f2pool-aleo-miner
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/aleo1tominer/h-manifest.conf

conf="-w ${CUSTOM_TEMPLATE} -u ${CUSTOM_URL}"


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

