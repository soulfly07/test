####################################################################################
###
### f2pool-aleo-miner
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/f2pool-aleo-miner/h-manifest.conf

conf="$CUSTOM_PASS $CUSTOM_NAME -w ${CUSTOM_TEMPLATE} -u ${CUSTOM_URL}"


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

